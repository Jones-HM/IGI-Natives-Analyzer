int __cdecl sub_497860(int a1)
{
  return ((int (__cdecl *)(int))dword_A94E84[*(_DWORD *)(a1 + 4)])(a1);
}