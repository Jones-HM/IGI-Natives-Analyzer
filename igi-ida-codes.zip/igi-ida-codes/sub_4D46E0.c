int __cdecl sub_4D46E0(int a1)
{
  int v1; // esi

  v1 = sub_4D4710();
  sub_4D4750(v1, 0, sub_4D4780, 0, 0, a1);
  return v1;
}