__int16 sub_4E0830()
{
  return word_548698;
}