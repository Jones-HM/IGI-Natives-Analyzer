char sub_427D80()
{
  return sub_401A20(dword_53BB3C);
}