char sub_482560()
{
  sub_4C1830(dword_5C1184);
  return sub_401A20(word_54097C);
}