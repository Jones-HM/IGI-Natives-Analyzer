int __cdecl sub_4215D0(_DWORD *a1)
{
  return sub_4248A0(a1, a1[8], a1[9], a1[10], a1[11], 0, 0);
}