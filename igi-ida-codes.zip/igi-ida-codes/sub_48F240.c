int __cdecl sub_48F240(char a1)
{
  int result; // eax

  result = a1;
  dword_5C8BE4 = a1;
  return result;
}