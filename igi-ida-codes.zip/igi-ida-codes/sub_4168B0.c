int sub_4168B0()
{
  return dword_57BAA0;
}