int __cdecl sub_4B9CA0(int a1, int a2)
{
  if ( sub_4BFC70(a1, a1 + 8) )
    return sub_4B9CD0(a1, a2, 0, 0);
  else
    return 0;
}