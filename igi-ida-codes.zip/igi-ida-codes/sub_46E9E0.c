int __cdecl sub_46E9E0(int a1, _DWORD *a2)
{
  int result; // eax

  result = a1 + 360;
  *a2 = a1 + 360;
  return result;
}