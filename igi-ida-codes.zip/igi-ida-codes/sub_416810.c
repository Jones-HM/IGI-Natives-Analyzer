char sub_416810()
{
  return byte_539543;
}