_DWORD *__cdecl sub_4A2430(int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10)
{
  _DWORD *result; // eax

  result = (_DWORD *)sub_4012A0(a1, word_543D4E, 0);
  result[8] = a2;
  result[9] = a3;
  result[10] = a4;
  result[11] = a5;
  result[12] = a6;
  result[13] = a7;
  result[14] = a8;
  result[15] = a9;
  result[16] = a10;
  return result;
}