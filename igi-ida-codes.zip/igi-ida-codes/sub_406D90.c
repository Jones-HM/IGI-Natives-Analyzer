char sub_406D90()
{
  sub_4C1830(dword_5690B0);
  sub_4C1830(dword_5690C8);
  sub_401A20(word_5383D8);
  return sub_401A20(word_5383DA);
}