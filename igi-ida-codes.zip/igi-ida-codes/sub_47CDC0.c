char sub_47CDC0()
{
  return byte_5C10E8;
}