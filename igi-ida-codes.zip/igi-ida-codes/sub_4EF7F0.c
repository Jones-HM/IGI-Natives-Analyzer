char **__cdecl sub_4EF7F0(int a1, char **a2)
{
  char *v2; // edi
  char **result; // eax

  v2 = sub_4F1180(a1);
  result = a2;
  strcpy(*a2, v2);
  return result;
}