int __cdecl sub_476EA0(int a1)
{
  int result; // eax

  result = a1;
  *(_DWORD *)(a1 + 1824) = 0;
  return result;
}