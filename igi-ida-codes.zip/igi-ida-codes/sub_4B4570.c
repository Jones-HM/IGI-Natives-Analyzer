double __cdecl sub_4B4570(float *a1, float *a2)
{
  return a1[3] * a2[3] + a1[2] * a2[2] + a1[1] * a2[1] + *a1 * *a2;
}