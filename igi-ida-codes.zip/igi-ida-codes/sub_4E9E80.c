int sub_4E9E80()
{
  int result; // eax

  sub_401A20(word_54DA60);
  result = 385;
  word_54DA60 = 385;
  word_54DA62 = 385;
  return result;
}