int __cdecl sub_43C2B0(int a1, int a2)
{
  int result; // eax

  result = a1;
  *(float *)(a1 + 316) = *(float *)(a2 + 4) + *(float *)(a1 + 316);
  return result;
}