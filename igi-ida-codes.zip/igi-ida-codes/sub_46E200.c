char sub_46E200()
{
  return sub_401A20(dword_53FE84);
}