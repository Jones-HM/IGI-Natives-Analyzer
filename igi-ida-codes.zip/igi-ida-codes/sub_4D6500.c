double __cdecl sub_4D6500(int a1, int a2)
{
  return *(float *)(sub_4D6460(a1, a2) + 44);
}