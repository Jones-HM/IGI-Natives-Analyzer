int __cdecl sub_4B7DF0(int *a1)
{
  return sub_4B7BF0(*a1);
}