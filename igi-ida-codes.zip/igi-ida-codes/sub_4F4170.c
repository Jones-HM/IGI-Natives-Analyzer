void __noreturn sub_4F4170()
{
  ErrorShow(aVehicleDeleteH);
  while ( 1 )
    ;
}