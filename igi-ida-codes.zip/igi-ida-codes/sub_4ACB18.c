int __cdecl sub_4ACB18(_DWORD *a1, char *a2)
{
  __int16 v3[6]; // [esp+0h] [ebp-Ch] BYREF

  __strgtold12((int)v3, &a2, a2, 0, 0, 0, 0);
  return sub_4ACAEC((unsigned __int16 *)v3, a1);
}