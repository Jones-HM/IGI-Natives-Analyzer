void sub_508E30()
{
  dword_A7B2A0 = 0;
}