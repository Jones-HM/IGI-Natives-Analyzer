int __cdecl sub_5317B0(int a1)
{
  sub_4D96F0(a1);
  return sub_4C7560(dword_A44344, a1);
}