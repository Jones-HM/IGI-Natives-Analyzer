char sub_4F40D0()
{
  return byte_54E1DA;
}