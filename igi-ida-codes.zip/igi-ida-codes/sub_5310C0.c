char sub_5310C0()
{
  return sub_401A20(word_54F7B0);
}