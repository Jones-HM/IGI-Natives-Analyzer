char sub_528420()
{
  sub_4C1830(dword_A83F44);
  sub_4C1830(dword_A84088);
  sub_401A20(word_A84374);
  return sub_401A20(word_A8408C);
}