int __cdecl sub_463740(int a1)
{
  int result; // eax
  int v2; // ecx

  result = 0;
  v2 = *(_DWORD *)(a1 + 1968);
  if ( v2 )
    return *(_DWORD *)v2;
  return result;
}