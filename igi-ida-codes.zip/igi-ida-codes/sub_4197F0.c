int __cdecl sub_4197F0(int a1)
{
  int result; // eax

  result = a1;
  *(_DWORD *)(a1 + 32) = 0;
  return result;
}