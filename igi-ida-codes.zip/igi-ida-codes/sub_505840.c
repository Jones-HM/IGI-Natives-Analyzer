_DWORD *__cdecl sub_505840(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = a1;
  return result;
}