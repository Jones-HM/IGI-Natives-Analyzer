int __cdecl sub_4977B0(const void *a1, int a2)
{
  _DWORD *v2; // ebx

  v2 = (_DWORD *)sub_497800(36);
  qmemcpy(v2, a1, 0x24u);
  v2[1] = sub_491DB0();
  return sub_4978B0(a2, v2);
}