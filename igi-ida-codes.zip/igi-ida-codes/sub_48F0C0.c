int __cdecl sub_48F0C0(int a1)
{
  int result; // eax

  result = a1;
  dword_5C8BC8 = a1;
  return result;
}