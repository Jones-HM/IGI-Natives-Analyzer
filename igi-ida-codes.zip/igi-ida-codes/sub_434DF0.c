char sub_434DF0()
{
  sub_4C1830(dword_57BD54);
  return sub_401A20(dword_53BEE8);
}