int __cdecl sub_4406D0(int a1, int *a2)
{
  int v2; // esi

  v2 = *a2;
  sub_491CF0();
  sub_491CF0();
  return sub_4871C0(v2, COERCE_FLOAT(v2 + 1172));
}