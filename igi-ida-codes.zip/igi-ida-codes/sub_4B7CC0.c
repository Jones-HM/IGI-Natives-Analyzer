int sub_4B7CC0()
{
  sub_4B0EB0(dword_A84A48);
  sub_4B0EB0(dword_A84A40);
  return sub_4B0EB0(dword_A84A44);
}