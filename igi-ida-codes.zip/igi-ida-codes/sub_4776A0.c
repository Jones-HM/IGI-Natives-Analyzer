int __cdecl sub_4776A0(int a1)
{
  int v1; // eax

  v1 = sub_4D9860(a1);
  return sub_4C17C0(v1);
}