char __cdecl sub_495260(int a1)
{
  return sub_495220(a1, &dword_5CA120);
}