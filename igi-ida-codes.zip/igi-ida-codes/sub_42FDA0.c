char sub_42FDA0()
{
  sub_4C1830(dword_57BD28);
  return sub_401A20(dword_53BDA8);
}