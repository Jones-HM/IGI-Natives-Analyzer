int __cdecl sub_48F200(int a1)
{
  int result; // eax

  result = a1;
  dword_5C8C04 = a1;
  return result;
}