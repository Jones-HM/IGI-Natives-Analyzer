int __cdecl sub_4D9800(int a1)
{
  return *(_DWORD *)(a1 + 72);
}