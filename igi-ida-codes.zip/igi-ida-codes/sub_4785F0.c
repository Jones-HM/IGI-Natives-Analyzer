int __cdecl sub_4785F0(int a1)
{
  int result; // eax

  result = a1;
  *(_BYTE *)(a1 + 240) = 0;
  *(_BYTE *)(a1 + 308) = 0;
  *(_DWORD *)(a1 + 316) = 0;
  *(_DWORD *)(a1 + 320) = 0;
  *(_DWORD *)(a1 + 328) = 0;
  *(_DWORD *)(a1 + 420) = 0;
  *(_DWORD *)(a1 + 424) = 0;
  *(_DWORD *)(a1 + 412) = 0;
  *(_DWORD *)(a1 + 416) = 0;
  *(_DWORD *)(a1 + 408) = 0;
  *(_DWORD *)(a1 + 428) = 0;
  return result;
}