int __cdecl sub_503B90(int a1)
{
  return sub_4C6840(dword_A44344, a1, 0);
}