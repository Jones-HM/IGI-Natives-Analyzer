char __cdecl sub_4FA8D0(int a1, double *a2)
{
  char v3; // [esp+4h] [ebp-Ch] BYREF
  double v4; // [esp+5h] [ebp-Bh]

  sub_4B17C0(*(_DWORD **)(a1 + 4));
  ResourceUnpack(*(_DWORD **)(a1 + 4), (int)&v3, 9);
  *a2 = v4;
  return 1;
}