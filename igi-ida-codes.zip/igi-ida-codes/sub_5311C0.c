char sub_5311C0()
{
  char result; // al

  result = sub_401A20(word_A84608);
  dword_A84610 = 0;
  return result;
}