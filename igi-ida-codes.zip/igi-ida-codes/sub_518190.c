double __cdecl sub_518190(double *a1, double a2)
{
  return a2 * a2 * a2 * a1[2] + a2 * a2 * a1[3] + a2 * *a1 + a1[1];
}