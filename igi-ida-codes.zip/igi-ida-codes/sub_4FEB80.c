int sub_4FEB80()
{
  sub_4C1830(dword_A7A500);
  sub_4C1830(dword_A7A4E4);
  sub_4C1830(dword_A7A4F0);
  sub_4C1830(dword_A7A4F8);
  sub_4C1830(dword_A7A4EC);
  sub_401A20(word_A7A4FC);
  sub_401A20(HIWORD(dword_A7A4F4));
  sub_401A20(word_A7A4E0);
  sub_401A20(word_A7A4FE);
  sub_401A20(word_A7A4E8);
  return sub_4018C0(dword_A7A4F4);
}