char sub_4167E0()
{
  return byte_539541;
}