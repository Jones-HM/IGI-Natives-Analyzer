int sub_498230()
{
  dword_BCAAA0 = 0;
  dword_BCAAA4 = 0;
  memset(&dword_BCAAC0, 0, 0x18u);
  dword_BCAAA8 = 0;
  return 1;
}