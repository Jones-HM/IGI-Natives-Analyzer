int __cdecl sub_463110(int a1)
{
  return *(_DWORD *)(a1 + 764);
}