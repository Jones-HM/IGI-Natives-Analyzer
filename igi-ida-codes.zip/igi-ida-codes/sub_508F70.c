char sub_508F70()
{
  return byte_54E831;
}