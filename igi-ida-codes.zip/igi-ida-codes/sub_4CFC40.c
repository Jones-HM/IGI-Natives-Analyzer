int sub_4CFC40()
{
  return dword_B81880;
}