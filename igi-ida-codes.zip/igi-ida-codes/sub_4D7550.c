int sub_4D7550()
{
  int v0; // edx
  int v1; // eax

  word_548618 = Allocate_TaskType((int)aBonedyncubeobj, 216, word_54875C, 0);
  byte_54861A = sub_4017C0(word_548618);
  sub_401400(word_548618, 4, (int)sub_5124C0);
  sub_401400(word_548618, 7, (int)sub_4D9480);
  sub_401400(word_548618, 9, (int)sub_4D7620);
  sub_401400(word_548618, 8, (int)sub_4D88D0);
  LOBYTE(v0) = byte_54861A;
  sub_401400(word_548618, v0, (int)sub_4F4390);
  LOBYTE(v1) = sub_4CEA10();
  sub_401400(word_548618, v1, (int)sub_4D94F0);
  return sub_401400(word_548618, 6, (int)sub_4D95A0);
}