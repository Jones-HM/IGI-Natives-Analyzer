int __cdecl sub_41A1D0(int a1)
{
  return *(char *)(a1 + 89);
}