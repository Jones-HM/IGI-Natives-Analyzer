int __cdecl sub_474960(int a1)
{
  int v1; // eax

  v1 = sub_4168A0();
  sub_4C17C0(v1);
  return sub_4C7560(*(_DWORD *)(a1 + 104), a1);
}