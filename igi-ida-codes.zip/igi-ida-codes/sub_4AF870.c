int __cdecl sub_4AF870(int a1)
{
  int result; // eax

  result = a1;
  dword_936270 = a1;
  return result;
}