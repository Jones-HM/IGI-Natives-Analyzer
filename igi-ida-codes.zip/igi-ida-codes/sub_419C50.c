int __cdecl sub_419C50(int a1, int a2)
{
  int v2; // esi
  unsigned __int16 v3; // ax

  v2 = 384 * (unsigned __int8)sub_4F1A70();
  v3 = sub_424850();
  return ((int (__cdecl *)(int, int))dword_A96AE0[v3 + v2])(a1, a2);
}