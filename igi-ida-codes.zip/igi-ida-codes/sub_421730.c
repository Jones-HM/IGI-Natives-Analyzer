int __cdecl sub_421730(int a1)
{
  return sub_4012A0(a1, word_53B7F0, a1);
}