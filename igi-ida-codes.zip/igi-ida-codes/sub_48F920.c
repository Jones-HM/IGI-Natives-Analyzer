int sub_48F920()
{
  return sub_48F280(1);
}