_DWORD *__cdecl sub_443A00(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_57C1A0;
  return result;
}