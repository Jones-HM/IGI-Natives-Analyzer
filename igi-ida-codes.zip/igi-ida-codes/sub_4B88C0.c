int __cdecl sub_4B88C0(int ArgList, int a2, int a3, int a4)
{
  return QTaskHashTableSet(ArgList, a2, a3, a4, 1, 1, 0);
}