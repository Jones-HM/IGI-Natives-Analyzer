int __cdecl sub_5116B0(int a1)
{
  int result; // eax

  result = a1;
  dword_A7DA40 = *(_DWORD *)(a1 + 3516);
  return result;
}