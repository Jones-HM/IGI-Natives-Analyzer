int sub_497D40()
{
  sub_4B0EB0(dword_6E5BA8);
  sub_4B0EB0(dword_6E5BA4);
  dword_543A68 = -1;
  return sub_497ED0();
}