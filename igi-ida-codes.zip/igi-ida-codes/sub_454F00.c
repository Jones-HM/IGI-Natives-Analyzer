_DWORD *__cdecl sub_454F00(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_5BDA84;
  return result;
}