int __cdecl sub_4018C0(unsigned __int8 a1)
{
  int result; // eax

  result = 3 * a1;
  byte_54F932[6 * a1] = 0;
  return result;
}