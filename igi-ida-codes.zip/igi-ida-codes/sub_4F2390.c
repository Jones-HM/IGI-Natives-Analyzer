int __cdecl sub_4F2390(int a1)
{
  ((void (__cdecl *)(int, int *))dword_A96AE0[384 * (unsigned __int8)dword_A76C08 + *(unsigned __int16 *)(a1 + 28)])(
    a1,
    &a1);
  return a1;
}