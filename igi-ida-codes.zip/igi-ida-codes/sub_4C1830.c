void __cdecl sub_4C1830(int a1)
{
  sub_4B0D10(a1);
}