_DWORD *__cdecl sub_51EC60(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_BA1FE0;
  return result;
}