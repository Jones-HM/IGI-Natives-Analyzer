unsigned int __cdecl sub_52C5A0(int a1, int a2)
{
  sub_4C7140(*(_DWORD **)(a1 + 104), a1, a1 + 240, 4096.0, 4);
  return sub_4C6E70(*(_DWORD **)(a2 + 4), a1, a1 + 312, (double *)(a1 + 264), (double *)(a1 + 288));
}