char sub_427280()
{
  return sub_401A20(dword_57BC7C);
}