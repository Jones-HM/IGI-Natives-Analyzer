_DWORD *__cdecl sub_4EDA70(_DWORD *a1)
{
  _DWORD *result; // eax

  result = a1;
  a1[8] = 0;
  a1[9] = 0;
  a1[10] = 0;
  a1[11] = 0;
  a1[12] = 0;
  a1[13] = 0;
  a1[14] = 1065353216;
  a1[15] = 1082130432;
  return result;
}