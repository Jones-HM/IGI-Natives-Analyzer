int __cdecl sub_42FC70(int a1, _DWORD *a2)
{
  int result; // eax

  result = a1 + 2704;
  *a2 = a1 + 2704;
  return result;
}