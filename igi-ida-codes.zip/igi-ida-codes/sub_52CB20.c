char sub_52CB20()
{
  return sub_401A20(word_54F718);
}