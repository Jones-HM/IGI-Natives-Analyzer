int sub_498070()
{
  return dword_6E5BA8;
}