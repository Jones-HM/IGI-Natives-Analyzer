char sub_416850()
{
  return byte_539548;
}