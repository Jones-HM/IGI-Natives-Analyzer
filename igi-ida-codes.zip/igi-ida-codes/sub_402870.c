int sub_402870()
{
  return *(_DWORD *)(dword_567C8C + 60);
}