_DWORD *__cdecl sub_4F43D0(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = 280;
  return result;
}