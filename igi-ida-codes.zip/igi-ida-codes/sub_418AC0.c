char sub_418AC0()
{
  char result; // al

  sub_4C1830(dword_57BAE0);
  result = sub_401A20(word_539824);
  word_539824 = 385;
  return result;
}