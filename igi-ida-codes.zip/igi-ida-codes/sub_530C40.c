int __cdecl sub_530C40(int a1)
{
  return sub_531250(*(_DWORD *)(a1 + 36), *(_DWORD *)(a1 + 32));
}