char sub_507D40()
{
  sub_4C1830(dword_A7B244);
  return sub_401A20(word_A7B248);
}