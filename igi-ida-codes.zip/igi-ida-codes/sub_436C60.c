int __cdecl sub_436C60(int a1)
{
  char v1; // bl

  *(_BYTE *)(a1 + 32) = 0;
  *(_BYTE *)(a1 + 33) = 0;
  *(_BYTE *)(a1 + 34) = 0;
  *(_BYTE *)(a1 + 35) = 0;
  *(_DWORD *)(a1 + 36) = dword_53C0B8;
  *(_WORD *)(a1 + 40) = word_53C0BC;
  v1 = byte_53C0BE;
  *(_DWORD *)(a1 + 56) = 0;
  *(_BYTE *)(a1 + 42) = v1;
  return sub_436CB0(a1);
}