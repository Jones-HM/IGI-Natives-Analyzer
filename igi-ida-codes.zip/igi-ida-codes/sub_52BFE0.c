_DWORD *__cdecl sub_52BFE0(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = 0;
  return result;
}