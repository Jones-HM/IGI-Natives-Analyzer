int __cdecl sub_5055D0(int a1, int a2)
{
  unsigned __int8 v2; // al

  v2 = sub_504E00();
  return ((int (__cdecl *)(int, int))dword_A96AE0[384 * v2 + *(unsigned __int16 *)(a1 + 28)])(a1, a2);
}