int __cdecl sub_4D7040(int a1, int a2)
{
  return (__int64)**(float **)(dword_A538F4[10 * a1] + 4 * a2);
}