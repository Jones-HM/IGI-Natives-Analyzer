char sub_4F4850()
{
  return byte_54E202;
}