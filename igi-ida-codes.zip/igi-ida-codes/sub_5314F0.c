char sub_5314F0()
{
  char result; // al

  sub_4B0B70(&dword_AFA800);
  sub_4B0B70(dword_AFA820);
  sub_401A20(word_54F800);
  word_54F800 = 385;
  result = sub_401A20(word_54F802);
  word_54F802 = 385;
  return result;
}