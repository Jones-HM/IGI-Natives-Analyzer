int __cdecl sub_419040(int a1)
{
  return *(_DWORD *)(a1 + 10208);
}