int __cdecl sub_46D740(int a1)
{
  int result; // eax

  result = a1;
  if ( *(_BYTE *)(a1 + 265) )
    return sub_4015F0(a1);
  return result;
}