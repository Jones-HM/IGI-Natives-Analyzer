_DWORD *__cdecl sub_528170(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_A84088;
  return result;
}