char sub_52CA60()
{
  return sub_401A20(word_54F700);
}