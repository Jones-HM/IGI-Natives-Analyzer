int sub_50A5C0()
{
  return 0;
}