int __cdecl sub_497920(_DWORD *a1, _DWORD *a2)
{
  return sub_4B0EC0(*a1, *a2, a2[1]);
}