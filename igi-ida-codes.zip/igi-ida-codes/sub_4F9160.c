void __cdecl sub_4F9160(int a1)
{
  if ( *(_DWORD *)(a1 + 108) )
  {
    sub_4B0D10(*(_DWORD *)(a1 + 108));
    *(_DWORD *)(a1 + 108) = 0;
  }
}