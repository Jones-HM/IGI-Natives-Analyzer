int __cdecl sub_4BC2A0(char *Buffer, const char *a2, const void *a3)
{
  return GameDataSymbolLoad(Buffer, "%s%p", a2, a3);
}