int __cdecl sub_4D63F0(int a1)
{
  return sub_4D6400(a1);
}