char __cdecl sub_43A5E0(int a1)
{
  return sub_43A5F0(a1);
}