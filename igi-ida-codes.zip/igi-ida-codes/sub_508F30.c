char sub_508F30()
{
  sub_4018C0(byte_54E830);
  sub_4018C0(byte_54E831);
  return sub_401A20(word_A7B298);
}