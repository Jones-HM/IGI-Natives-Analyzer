int __cdecl sub_418FB0(int a1)
{
  return a1 + 10188;
}