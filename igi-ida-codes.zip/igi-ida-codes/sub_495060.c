int sub_495060()
{
  sub_495260(sub_493820);
  sub_48F4F0((int)sub_494F50);
  sub_4B7450(dword_BCADC4, dword_BCACEC);
  sub_4B7450(dword_BCADC4, dword_BCADE0);
  sub_4C1830(dword_BCADE8);
  sub_4C1830(dword_BCAD7C);
  sub_4C1830(dword_BCADAC);
  sub_4C1830(dword_BCADC4);
  return sub_4B0E50(dword_5CA0E0);
}