__int16 sub_4F8FD0()
{
  return word_A76CDC;
}