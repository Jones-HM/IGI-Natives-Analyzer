void __noreturn sub_4FB2A0()
{
  ErrorShow(aPhysicsobjDele);
  while ( 1 )
    ;
}