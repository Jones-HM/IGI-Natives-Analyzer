int __cdecl sub_528850(int a1)
{
  int result; // eax

  result = a1;
  *(_DWORD *)(a1 + 328) = 0;
  *(_DWORD *)(a1 + 336) = 0;
  *(_DWORD *)(a1 + 344) = 0;
  *(_DWORD *)(a1 + 352) = 0;
  *(_DWORD *)(a1 + 360) = 0;
  *(_DWORD *)(a1 + 368) = 0;
  *(_BYTE *)(a1 + 212) = 0;
  *(_BYTE *)(a1 + 415) = 1;
  *(_DWORD *)(a1 + 256) = sub_528930;
  *(_DWORD *)(a1 + 264) = -1;
  *(_DWORD *)(a1 + 268) = -1;
  *(_DWORD *)(a1 + 332) = 0;
  *(_DWORD *)(a1 + 340) = 0;
  *(_DWORD *)(a1 + 348) = 0;
  *(_DWORD *)(a1 + 356) = 0;
  *(_DWORD *)(a1 + 364) = 0;
  *(_DWORD *)(a1 + 372) = 0;
  *(_BYTE *)(a1 + 320) = 0;
  *(_BYTE *)(a1 + 321) = 0;
  *(_DWORD *)(a1 + 376) = 0;
  *(_DWORD *)(a1 + 380) = 0;
  *(_DWORD *)(a1 + 384) = 0;
  *(_DWORD *)(a1 + 388) = 0;
  *(_DWORD *)(a1 + 392) = 0;
  *(_DWORD *)(a1 + 396) = 0;
  *(_DWORD *)(a1 + 400) = 0;
  *(_DWORD *)(a1 + 404) = 0;
  *(_DWORD *)(a1 + 408) = 0;
  *(_BYTE *)(a1 + 412) = 0;
  *(_BYTE *)(a1 + 413) = 0;
  *(_BYTE *)(a1 + 414) = 0;
  *(_DWORD *)(a1 + 416) = 1;
  return result;
}