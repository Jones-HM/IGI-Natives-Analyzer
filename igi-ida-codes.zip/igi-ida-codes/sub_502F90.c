_DWORD *__cdecl sub_502F90(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_A7A508;
  return result;
}