int __cdecl sub_505A30(int a1)
{
  int v2; // [esp+0h] [ebp-Ch] BYREF
  int v3; // [esp+4h] [ebp-8h]
  int v4; // [esp+8h] [ebp-4h]

  v2 = 0;
  v3 = 0;
  v4 = 0;
  sub_505920(a1, sub_505A60, (int)&v2);
  return v3;
}