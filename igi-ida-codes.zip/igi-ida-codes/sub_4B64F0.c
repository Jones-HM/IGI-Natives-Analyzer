int __cdecl sub_4B64F0(int *a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9)
{
  return sub_4B23B0((int *)(a1[1] + 36 * a2), *a1, a4, a5, a6, a7, a8, a9, a3);
}