int __cdecl sub_525320(int a1)
{
  QhashInit(1);
  sub_4B2610(1);
  sub_4B2320((int *)a1, 0, 4 * *(__int16 *)(a1 + 40), *(__int16 *)(a1 + 40), *(__int16 *)(a1 + 42), 3, 0, -1475870660);
  sub_4B2610(-1);
  return QhashReset();
}