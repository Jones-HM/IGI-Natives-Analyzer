char sub_52AFB0()
{
  char result; // al

  sub_4C1830(dword_A84394);
  result = sub_401A20(word_54F68C);
  word_54F68C = 385;
  return result;
}