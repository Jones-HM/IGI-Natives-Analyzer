bool __cdecl sub_48DC30(int a1)
{
  nullsub_1();
  sub_48EF70(a1, 1, 1.0);
  *(_DWORD *)(a1 + 15484) = 1065353216;
  *(_DWORD *)(a1 + 15860) = 1;
  return (unsigned __int8)sub_48EFE0(a1, 1) != 0;
}