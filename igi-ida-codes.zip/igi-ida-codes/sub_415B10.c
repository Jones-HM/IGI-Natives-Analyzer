int __cdecl sub_415B10(char *String)
{
  *(_DWORD *)ArgList = atoi(String);
  return sub_48F210(0);
}