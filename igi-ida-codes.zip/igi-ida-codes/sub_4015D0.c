int __cdecl sub_4015D0(int a1)
{
  int result; // eax

  result = a1;
  if ( *(_DWORD *)(a1 + 20) )
    return sub_4AF960(a1);
  return result;
}