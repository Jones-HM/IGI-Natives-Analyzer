char PlayerXPHit()
{
  return *(_BYTE *)(dword_57BABC + 225);
}