int __cdecl sub_4BA340(int a1)
{
  int result; // eax

  switch ( a1 )
  {
    case 3:
    case 4:
    case 13:
    case 20:
      result = 1;
      break;
    default:
      result = 0;
      break;
  }
  return result;
}