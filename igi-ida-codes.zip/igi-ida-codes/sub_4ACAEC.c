int __cdecl sub_4ACAEC(unsigned __int16 *a1, _DWORD *a2)
{
  return _ld12cvt(a1, a2, dword_546AC0);
}