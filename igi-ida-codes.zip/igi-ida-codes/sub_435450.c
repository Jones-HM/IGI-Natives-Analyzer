char sub_435450()
{
  return sub_401A20(dword_57BD5C);
}