int __cdecl sub_531200(_DWORD *a1)
{
  return sub_4DA8D0(a1 + 8, a1 + 26, a1[29]);
}