int __cdecl sub_4F65C0(int a1)
{
  int result; // eax

  result = a1;
  dword_A76C80 = a1;
  return result;
}