int __cdecl sub_422F10(int a1)
{
  unsigned __int16 v1; // ax

  sub_4028B0();
  v1 = sub_424850();
  return ((int (__cdecl *)(int))dword_A970E0[v1])(a1);
}