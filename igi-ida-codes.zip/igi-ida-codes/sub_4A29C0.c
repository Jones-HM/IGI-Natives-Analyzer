int __cdecl sub_4A29C0(int a1, int a2, int a3)
{
  int result; // eax

  result = a1;
  *(_DWORD *)dword_936020 = a1;
  dword_936028 = a2;
  dword_93602C = a3;
  return result;
}