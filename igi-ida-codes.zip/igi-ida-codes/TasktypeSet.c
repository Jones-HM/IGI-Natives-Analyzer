int __cdecl TasktypeSet(int ArgList, int a2)
{
  return QTaskHashTableSet(ArgList, (int)sub_4B8830, a2, 4, 2, 1, 0);
}