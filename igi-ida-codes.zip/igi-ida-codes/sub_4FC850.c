char sub_4FC850()
{
  return byte_54E4CD;
}