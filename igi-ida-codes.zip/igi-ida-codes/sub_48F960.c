int sub_48F960()
{
  return sub_48F2B0(0);
}