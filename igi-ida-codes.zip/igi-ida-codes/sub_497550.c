void sub_497550()
{
  dword_684100 = (int)&dword_684104;
  dword_684108 = (int)&dword_684100;
  dword_684104 = 0;
}