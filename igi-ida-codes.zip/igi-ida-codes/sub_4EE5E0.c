void __cdecl sub_4EE5E0(int a1)
{
  if ( sub_4EE940() )
    sub_4EE6B0(*(const char **)(a1 + 32));
}