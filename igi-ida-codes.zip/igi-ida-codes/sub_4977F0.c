void sub_4977F0()
{
  dword_6E5B98 = (int)&unk_684118;
}