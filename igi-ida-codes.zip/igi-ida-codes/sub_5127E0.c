void sub_5127E0()
{
  nullsub_2();
}