_DWORD *__cdecl sub_43AD30(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_57BEF4;
  return result;
}