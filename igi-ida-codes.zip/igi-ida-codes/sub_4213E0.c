char sub_4213E0()
{
  char result; // al

  sub_4C1830(dword_57BBF4);
  sub_4B8920((char)aTextBlack);
  sub_4B8920((char)aTextWhite);
  sub_4B8920((char)aTextGreen);
  sub_4B8920((char)aTextOrange);
  result = sub_401A20(word_53B770);
  word_53B770 = 385;
  return result;
}