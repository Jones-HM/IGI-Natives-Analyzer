int sub_424890()
{
  return dword_53B91C;
}