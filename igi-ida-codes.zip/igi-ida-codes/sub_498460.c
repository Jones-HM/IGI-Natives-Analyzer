void sub_498460()
{
  word_6E5BC4 |= 0xC00u;
}