char sub_4F9220()
{
  return byte_54E36B;
}