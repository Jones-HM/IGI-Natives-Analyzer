__int16 __cdecl sub_481340()
{
  return word_54097C;
}