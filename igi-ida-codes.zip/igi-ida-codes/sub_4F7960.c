_DWORD *__cdecl sub_4F7960(int a1)
{
  _DWORD *v1; // eax

  v1 = (_DWORD *)sub_497800(16);
  v1[1] = dword_A76C8C;
  v1[3] = a1;
  return sub_4978B0(0, v1);
}