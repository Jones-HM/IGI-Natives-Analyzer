int __cdecl sub_463600(int a1)
{
  int result; // eax

  result = a1;
  *(_BYTE *)(a1 + 1296) = 0;
  return result;
}