int sub_4DAA00()
{
  int result; // eax

  result = dword_B03F90;
  if ( dword_B03F90 == dword_B03DF0 )
    --dword_B03DF0;
  --dword_B03F90;
  return result;
}