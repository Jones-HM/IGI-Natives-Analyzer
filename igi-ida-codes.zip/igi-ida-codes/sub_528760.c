int __cdecl sub_528760(int a1)
{
  memset((void *)(a1 + 216), 0xFFu, 0x28u);
  *(_DWORD *)(a1 + 440) = -1;
  *(_DWORD *)(a1 + 444) = -1;
  *(_DWORD *)(a1 + 448) = 0;
  *(_DWORD *)(a1 + 456) = 0;
  *(_DWORD *)(a1 + 464) = 0;
  *(_DWORD *)(a1 + 472) = 0;
  *(_DWORD *)(a1 + 480) = 0;
  *(_DWORD *)(a1 + 488) = 0;
  *(_DWORD *)(a1 + 136) = 0;
  *(_DWORD *)(a1 + 452) = 0;
  *(_DWORD *)(a1 + 460) = 0;
  *(_DWORD *)(a1 + 468) = 0;
  *(_DWORD *)(a1 + 476) = 0;
  *(_DWORD *)(a1 + 484) = 0;
  *(_DWORD *)(a1 + 492) = 0;
  *(_DWORD *)(a1 + 496) = 0;
  *(_DWORD *)(a1 + 500) = 0;
  *(_DWORD *)(a1 + 504) = 0;
  *(_DWORD *)(a1 + 508) = 0;
  *(_DWORD *)(a1 + 512) = 0;
  *(_DWORD *)(a1 + 516) = 0;
  *(_DWORD *)(a1 + 520) = 0;
  *(_DWORD *)(a1 + 524) = 0;
  *(_DWORD *)(a1 + 528) = 0;
  *(_BYTE *)(a1 + 532) = 0;
  *(_BYTE *)(a1 + 533) = 0;
  *(_BYTE *)(a1 + 534) = 0;
  strcpy((char *)(a1 + 424), "(Default)");
  return sub_528850(a1);
}