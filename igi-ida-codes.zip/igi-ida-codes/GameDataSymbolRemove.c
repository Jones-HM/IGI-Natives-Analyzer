int __cdecl GameDataSymbolRemove(char ArgList)
{
  return sub_4B8920(ArgList);
}