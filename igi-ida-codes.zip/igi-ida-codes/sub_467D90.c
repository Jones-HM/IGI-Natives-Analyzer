char sub_467D90()
{
  char result; // al

  result = byte_53F582;
  if ( byte_53F582 == -1 )
  {
    result = sub_4017C0(385);
    byte_53F582 = result;
  }
  return result;
}