int sub_497EC0()
{
  return dword_6E5BB4;
}