void sub_4DA2F0()
{
  dword_A5E300 = 0;
}