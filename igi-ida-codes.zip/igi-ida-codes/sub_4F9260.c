char sub_4F9260()
{
  return byte_54E36F;
}