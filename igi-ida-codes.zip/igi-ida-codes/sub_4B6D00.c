int __cdecl sub_4B6D00(int a1)
{
  return *(__int16 *)(*(_DWORD *)(a1 + 8) + 36 * *(unsigned __int16 *)(a1 + 20) + 14);
}