_DWORD *__cdecl sub_4EFA10(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = 1;
  return result;
}