_DWORD *__cdecl sub_407B90(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_569204;
  return result;
}