void sub_52C7A0()
{
  nullsub_1();
}