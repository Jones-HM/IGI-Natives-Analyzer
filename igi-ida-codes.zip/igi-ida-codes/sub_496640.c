int __cdecl sub_496640(int a1, int a2)
{
  return sub_4AF960(a2);
}