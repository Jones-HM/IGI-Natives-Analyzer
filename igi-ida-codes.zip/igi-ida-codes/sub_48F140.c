int __cdecl sub_48F140(int a1)
{
  int result; // eax

  result = a1;
  dword_5C8BFC = (char)a1;
  if ( dword_5C8C18 )
    return dword_5C8C18(a1, dword_5C8C1C);
  return result;
}