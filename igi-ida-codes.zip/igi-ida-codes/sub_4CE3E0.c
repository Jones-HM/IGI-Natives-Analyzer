int __cdecl sub_4CE3E0(int a1, int a2, int a3)
{
  int result; // eax

  result = a3;
  *(_DWORD *)(a1 + 4 * a2 + 3388) = a3;
  return result;
}