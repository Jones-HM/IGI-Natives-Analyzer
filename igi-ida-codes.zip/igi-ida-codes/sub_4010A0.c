void __noreturn sub_4010A0()
{
  longjmp(Buf, 1);
}