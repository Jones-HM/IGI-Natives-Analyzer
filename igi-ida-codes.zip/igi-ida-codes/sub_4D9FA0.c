__int16 sub_4D9FA0()
{
  return dword_548648;
}