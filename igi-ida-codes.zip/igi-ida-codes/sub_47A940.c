int __cdecl sub_47A940(int a1, _DWORD *a2)
{
  int result; // eax

  result = a1 + 376;
  *a2 = **(_DWORD **)(a1 + 304);
  a2[1] = a1 + 376;
  return result;
}