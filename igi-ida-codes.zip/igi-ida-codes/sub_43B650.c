int __cdecl sub_43B650(int a1)
{
  unsigned __int16 v1; // ax

  v1 = sub_481340();
  ((void (__cdecl *)(int))dword_A976E0[v1])(a1);
  return sub_4F1340(a1 + 576);
}