void __cdecl sub_48E520(int a1)
{
  nullsub_1();
  sub_4513F0(a1);
}