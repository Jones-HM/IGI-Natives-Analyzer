int __cdecl sub_4B70F0(int a1)
{
  return sub_4B6D00(a1);
}