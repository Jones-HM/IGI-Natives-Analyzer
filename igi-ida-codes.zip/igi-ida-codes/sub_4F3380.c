__int16 sub_4F3380()
{
  return dword_54E1AC;
}