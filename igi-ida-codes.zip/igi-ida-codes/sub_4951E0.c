_DWORD *__cdecl sub_4951E0(int a1)
{
  return sub_495190(a1, &dword_5CA11C);
}