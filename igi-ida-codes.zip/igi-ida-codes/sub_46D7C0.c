_DWORD *__cdecl sub_46D7C0(int a1, _DWORD *a2)
{
  _DWORD *result; // eax

  result = a2;
  *a2 = dword_5BE304;
  return result;
}