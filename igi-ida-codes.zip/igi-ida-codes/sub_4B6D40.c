int __cdecl sub_4B6D40(int a1)
{
  return HIWORD(*(_DWORD *)(*(_DWORD *)(a1 + 8) + 36 * *(unsigned __int16 *)(a1 + 20) + 4)) & 1;
}