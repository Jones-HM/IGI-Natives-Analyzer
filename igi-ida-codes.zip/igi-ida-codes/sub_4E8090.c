int __cdecl sub_4E8090(int a1)
{
  sub_4C1830(*(_DWORD *)(a1 + 196));
  if ( !--dword_A5EC60 )
    nullsub_1();
  sub_4975F0(a1 + 84);
  return sub_518250(*(_DWORD *)(a1 + 172));
}