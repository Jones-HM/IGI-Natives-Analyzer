int sub_48F340()
{
  return dword_5C8BF0;
}