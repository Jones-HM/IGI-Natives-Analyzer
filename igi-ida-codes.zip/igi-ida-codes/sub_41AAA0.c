int __cdecl sub_41AAA0(int a1)
{
  int result; // eax

  result = a1;
  if ( *(_DWORD *)(a1 + 84) )
    *(_DWORD *)(a1 + 84) = 0;
  return result;
}