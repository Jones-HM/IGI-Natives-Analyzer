int sub_4CEA70()
{
  return dword_548204;
}