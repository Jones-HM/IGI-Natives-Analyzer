void __cdecl sub_4C03C0(_DWORD *a1)
{
  sub_4C03F0(a1);
  sub_4B0D10(*a1);
  *a1 = 0;
  sub_4B0D10(a1);
}