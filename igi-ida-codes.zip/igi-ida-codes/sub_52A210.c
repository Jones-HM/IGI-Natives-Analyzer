char sub_52A210()
{
  sub_4C1830(dword_A84388);
  return sub_401A20(word_54F198);
}