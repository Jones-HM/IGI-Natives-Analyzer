int __cdecl sub_4C0240(int a1)
{
  return *(_DWORD *)(*(_DWORD *)a1 + 4);
}