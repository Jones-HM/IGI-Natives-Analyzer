void sub_51C290()
{
  sub_401A20(word_54EE3C);
  sub_4C1830(dword_A83780);
}