char __cdecl sub_4FAF50(int *a1)
{
  memset(&dword_A77260, 0, 0x240u);
  a1[2] = 0;
  return sub_4F9CD0(a1, (float *)&dword_A77260, 0);
}