char sub_4F4130()
{
  return byte_54E1DF;
}