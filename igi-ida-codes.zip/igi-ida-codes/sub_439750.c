int __cdecl sub_439750(int a1)
{
  int result; // eax

  result = a1;
  if ( *(_BYTE *)(a1 + 312) )
    *(_BYTE *)(a1 + 424) = 1;
  return result;
}